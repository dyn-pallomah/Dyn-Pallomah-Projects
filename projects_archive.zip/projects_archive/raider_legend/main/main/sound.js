var sound= {
	play: name=> {
		new Audio(`sound/${name}.wav`).play();
	},
}
