var teleport= {
  key: new Array(),
  p1x: new Array(),
  p1y: new Array(),
  p2x: new Array(),
  p2y: new Array(),
}
