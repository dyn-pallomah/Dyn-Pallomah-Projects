var statistics= {
  name: [
    'object',
    ' ',
    '*',
    '.',
    '$',
    '#',
  ],
  value: new Array(6),
  reset: ()=> {for(var i= 0; i< statistics.value.length; i++) statistics.value[i]= 0;},
}
