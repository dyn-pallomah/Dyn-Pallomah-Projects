var slope_unit= {
	x: [],
	y: [],

	setblk: function(x, y) {
		slope_unit.x.push(x);
		slope_unit.y.push(y);
	},
}
