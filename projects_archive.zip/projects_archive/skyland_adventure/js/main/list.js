var bl= [
	'null',
	'null',
	'exit',
	'flag',
	'soil',
	'null',
	'spike',
	'log',
	'vine',
	'slime',
	'soil_slope',
	'soil_slope',
	'soil_slope',
	'soil_slope',
];
var trsp= [
	undefined,
	0, 1, 2, 3, 5, 6, 7, 8
];
var pbl= [
	2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13
];
var el= [
	'cloud',
	'moss',
	'sprout',
	'mouse',
];
